from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Poubelle, CapteurPresence  # Import du modèle personnalisé

admin.site.register(User, UserAdmin)
# admin.py
from django.contrib import admin
from .models import Salle, Thermostat

class ThermostatInline(admin.StackedInline):
    model = Thermostat
    extra = 1  # Permet d'ajouter un thermostat directement dans la page de la salle

class SalleAdmin(admin.ModelAdmin):
    list_display = ['nom', 'capacite', 'disponible']
    search_fields = ['nom']
    inlines = [ThermostatInline]  # Permet d'ajouter un thermostat à partir de la page de la salle

class ThermostatAdmin(admin.ModelAdmin):
    list_display = ['id_unique', 'nom', 'temperature_courante', 'temperature_cible', 'mode', 'connectivite', 'etat_batterie', 'derniere_interaction']
    search_fields = ['nom', 'id_unique']  # Recherche par le nom du thermostat ou son ID unique

class PoubelleAdmin(admin.ModelAdmin):
    list_display = ['id_unique', 'type_dechet', 'couleur', 'capacite_maximale', 'quantite_present', 'salle']
    search_fields = ['id_unique', 'type_dechet', 'salle__nom']
    list_filter = ['type_dechet', 'salle']  # Pour filtrer par type de déchet et salle

class CapteurPresenceAdmin(admin.ModelAdmin):
    list_display = ['salle', 'compteur']
    search_fields = ['salle__nom']

admin.site.register(Salle)
admin.site.register(CapteurPresence, CapteurPresenceAdmin)
admin.site.register(Poubelle, PoubelleAdmin)
admin.site.register(Thermostat, ThermostatAdmin)


