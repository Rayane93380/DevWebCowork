# urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Page de connexion
    path('connexion/', views.connexion, name='connexion'),

    # Page d'inscription
    path('inscription/', views.inscription, name='inscription'),

    # Dashboard utilisateur (après connexion)
    path('dashboard/', views.dashboard, name='dashboard'),

    # Affichage des objets connectés
    path('objets_connectes/<str:objet_type>/', views.afficher_objets, name='afficher_objets'),

    # Réserver un objet (imprimante ou ordinateur)
    path('reserver/<str:objet_type>/<int:objet_id>/', views.reserver_objet, name='reserver_objet'),
]
