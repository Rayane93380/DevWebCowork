from django.urls import path
from .views import signup, login_user, logout_user, visiteur_index2, afficher_objets, reserver_salle, modifier_temp, \
    vider_poubelle, reserver_PC, modifier_profil, activate, email_verification_sent

urlpatterns = [
    path('', signup, name='signup'),
    path('login/', login_user, name='login'),
    path('logout/', logout_user, name='logout'),
    path('visiteur_index2', visiteur_index2, name="visiteur_index2"),
    path('objets/<str:objet_type>/', afficher_objets, name='afficher_objets'),
    path('reserver_salle/<int:salle_id>/', reserver_salle, name='reserver_salle'),
    path('afficher_salles/', afficher_objets, name='afficher_salles'),  # Ajout de l'URL pour afficher les salles
    path('modifier_temp/<int:thermostat_id>/', modifier_temp, name='modifier_temp'),
    path('vider_poubelle/<int:poubelle_id>/', vider_poubelle, name='vider_poubelle'),
    path('reserver_salle/', reserver_salle, name='reserver_salle'),
    path('reserver_PC/', reserver_PC, name='reserver_PC'),
    path('modifier-profil/', modifier_profil, name='modifier_profil'),
    path('objets_connectes/<str:objet_type>/', afficher_objets, name='afficher_objets'),
    path('activate/<uidb64>/<token>/', activate, name='activate'),
    path("email-verification-sent/", email_verification_sent, name="email_verification_sent"),
]
