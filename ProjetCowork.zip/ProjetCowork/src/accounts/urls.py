from django.urls import path
from .views import signup, login_user, logout_user, visiteur_index2, temperature_salles2, liste_salles2, poubelles_vides2, ordi_dispo2, reserver_salle, reserver_PC, modifier_temp


urlpatterns = [
    path('', signup, name='signup'),
    path('login/', login_user, name='login'),
    path('logout/', logout_user, name='logout'),
    path('visiteur_index2', visiteur_index2, name="visiteur_index2"),
    path('temperature_salles2/', temperature_salles2, name='temperature_salles2'),
    path('liste_salles2/', liste_salles2, name='liste_salles2'),
    path('poubelles_vides2/', poubelles_vides2, name='poubelles_vides2'),
    path('ordi_dispo2/', ordi_dispo2, name='ordi_dispo2'),
    path('reserver_salle/', reserver_salle, name='reserver_salle'),
    path('reserver_PC/', reserver_PC, name='reserver_PC'),
    path('temperature_salles2/modifier_temp/', modifier_temp, name='modifier_temp'),
]