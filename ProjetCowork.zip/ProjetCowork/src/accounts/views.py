# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from pyexpat.errors import messages

from .models import Salle, Imprimante, Ordinateur, CapteurPresence, Thermostat, Poubelle

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm


def inscription(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Votre compte a été créé avec succès !')
            return redirect('connexion')  # Redirige vers la page de connexion après inscription
    else:
        form = UserCreationForm()
    return render(request, 'accounts/inscription_index.html', {'form': form})

def connexion(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')  # Redirige vers la page du tableau de bord
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})


def dashboard(request):
    # Récupérer les objets connectés
    return render(request, 'accounts/dashboard.html')

@login_required
def afficher_objets(request, objet_type):
    """
    Affiche les objets connectés d'un type spécifique (imprimante, ordinateur, thermostat, etc.)
    """
    if objet_type == 'capteurpresence':
        objets = CapteurPresence.objects.all()
    elif objet_type == 'thermostat':
        objets = Thermostat.objects.all()
    elif objet_type == 'poubelle':
        objets = Poubelle.objects.all()
    elif objet_type == 'imprimante':
        objets = Imprimante.objects.all()
    elif objet_type == 'ordinateur':
        objets = Ordinateur.objects.all()
    else:
        return redirect('dashboard')  # Redirection si le type d'objet n'est pas valide

    context = {
        'objets': objets,
        'objet_type': objet_type,
    }
    return render(request, 'accounts/afficher_objets.html', context)

# views.py
from django.shortcuts import render, redirect
from .models import Imprimante, Ordinateur, Reservation
from django.contrib.auth.decorators import login_required
from datetime import datetime


@login_required
def reserver_objet(request, objet_type, objet_id):
    """
    Gérer la réservation d'un objet (imprimante ou ordinateur)
    """
    if objet_type == 'imprimante':
        objet = Imprimante.objects.get(id=objet_id)
    elif objet_type == 'ordinateur':
        objet = Ordinateur.objects.get(id=objet_id)
    else:
        return redirect('afficher_objets')

    # Vérification si l'objet est réservable
    if not objet.reservable or objet.maintenance_due:
        return render(request, 'error.html', {'message': 'Cet objet n\'est pas disponible pour réservation.'})

    # Créer une nouvelle réservation
    reservation = Reservation.objects.create(user=request.user, objet_type=objet_type, objet_id=objet.id)

    # Incrémenter le compteur de réservations
    objet.reservation_count += 1
    if objet.reservation_count >= 4:
        # Si l'objet atteint 4 réservations, mettre à jour le champ maintenance_due
        objet.maintenance_due = True
        objet.reservable = False  # Marquer l'objet comme non réservable
    objet.save()

    return redirect('afficher_objets')


@login_required
def annuler_reservation(request, reservation_id):
    """
    Annuler une réservation existante
    """
    reservation = Reservation.objects.get(id=reservation_id)

    if reservation.user != request.user:
        return redirect(
            'afficher_objets')  # Si l'utilisateur essaie de modifier une réservation qui n'est pas la sienne

    # Supprimer la réservation
    reservation.delete()

    # Récupérer l'objet réservé
    if reservation.objet_type == 'imprimante':
        objet = Imprimante.objects.get(id=reservation.objet_id)
    elif reservation.objet_type == 'ordinateur':
        objet = Ordinateur.objects.get(id=reservation.objet_id)

    # Décrémenter le compteur de réservations
    objet.reservation_count -= 1
    if objet.reservation_count < 4:
        # Si le nombre de réservations est inférieur à 4, remettre l'objet en état réservable
        objet.maintenance_due = False
        objet.reservable = True
    objet.save()

    return redirect('afficher_objets')
